package me.bluejay.levelheaded.client;

import me.bluejay.levelheaded.core.math.SurveyMath;

public final class ShotLog {
    private ShotLog() {}

    public static void capture(String kind, double x, double y, double z,
                               SurveyMath.Result result, String description) {
        // TODO: port CSV append from mc262
    }

    public static void saveLast() {
        // TODO: port
    }
}